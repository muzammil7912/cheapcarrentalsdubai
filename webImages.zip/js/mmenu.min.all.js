/*
 * jQuery mmenu v5.5.1
 * @requires jQuery 1.7.0 or later
 *
 * mmenu.frebsite.nl
 *	
 * Copyright (c) Fred Heusschen
 * www.frebsite.nl
 *
 * Licensed under the MIT license:
 * http://en.wikipedia.org/wiki/MIT_License
 */
 ! function(e) {
    function n() { e[t].glbl || (l = { $wndw: e(window), $html: e("html"), $body: e("body") }, a = {}, i = {}, r = {}, e.each([a, i, r], function(e, n) { n.add = function(e) { e = e.split(" ");
                for (var t = 0, s = e.length; s > t; t++) n[e[t]] = n.mm(e[t]) } }), a.mm = function(e) {
            return "mm-" + e }, a.add("wrapper menu panels panel nopanel current highest opened subopened navbar hasnavbar title btn prev next listview nolistview inset vertical selected divider spacer hidden fullsubopen"), a.umm = function(e) {
            return "mm-" == e.slice(0, 3) && (e = e.slice(3)), e }, i.mm = function(e) {
            return "mm-" + e }, i.add("parent sub"), r.mm = function(e) {
            return e + ".mm" }, r.add("transitionend webkitTransitionEnd mousedown mouseup touchstart touchmove touchend click keydown"), e[t]._c = a, e[t]._d = i, e[t]._e = r, e[t].glbl = l) }
    var t = "mmenu",
        s = "5.5.1";
    if (!(e[t] && e[t].version > s)) { e[t] = function(e, n, t) { this.$menu = e, this._api = ["bind", "init", "update", "setSelected", "getInstance", "openPanel", "closePanel", "closeAllPanels"], this.opts = n, this.conf = t, this.vars = {}, this.cbck = {}, "function" == typeof this.___deprecated && this.___deprecated(), this._initMenu(), this._initAnchors();
            var s = this.$pnls.children();
            return this._initAddons(), this.init(s), "function" == typeof this.___debug && this.___debug(), this }, e[t].version = s, e[t].addons = {}, e[t].uniqueId = 0, e[t].defaults = { extensions: [], navbar: { add: !0, title: "Menu", titleLink: "panel" }, onClick: { setSelected: !0 }, slidingSubmenus: !0 }, e[t].configuration = { classNames: { divider: "Divider", inset: "Inset", panel: "Panel", selected: "Selected", spacer: "Spacer", vertical: "Vertical" }, clone: !1, openingInterval: 25, panelNodetype: "ul, ol, div", transitionDuration: 400 }, e[t].prototype = { init: function(e) { e = e.not("." + a.nopanel), e = this._initPanels(e), this.trigger("init", e), this.trigger("update") }, update: function() { this.trigger("update") }, setSelected: function(e) { this.$menu.find("." + a.listview).children().removeClass(a.selected), e.addClass(a.selected), this.trigger("setSelected", e) }, openPanel: function(n) {
                var s = n.parent();
                if (s.hasClass(a.vertical)) {
                    var i = s.parents("." + a.subopened);
                    if (i.length) return this.openPanel(i.first());
                    s.addClass(a.opened) } else {
                    if (n.hasClass(a.current)) return;
                    var r = this.$pnls.children("." + a.panel),
                        l = r.filter("." + a.current);
                    r.removeClass(a.highest).removeClass(a.current).not(n).not(l).not("." + a.vertical).addClass(a.hidden), e[t].support.csstransitions || l.addClass(a.hidden), n.hasClass(a.opened) ? n.nextAll("." + a.opened).addClass(a.highest).removeClass(a.opened).removeClass(a.subopened) : (n.addClass(a.highest), l.addClass(a.subopened)), n.removeClass(a.hidden).addClass(a.current), setTimeout(function() { n.removeClass(a.subopened).addClass(a.opened) }, this.conf.openingInterval) }
                this.trigger("openPanel", n) }, closePanel: function(e) {
                var n = e.parent();
                n.hasClass(a.vertical) && (n.removeClass(a.opened), this.trigger("closePanel", e)) }, closeAllPanels: function() { this.$menu.find("." + a.listview).children().removeClass(a.selected).filter("." + a.vertical).removeClass(a.opened);
                var e = this.$menu.children("." + a.panel),
                    n = e.first();
                this.$menu.children("." + a.panel).not(n).removeClass(a.subopened).removeClass(a.opened).removeClass(a.current).removeClass(a.highest).addClass(a.hidden), this.openPanel(n) }, togglePanel: function(e) {
                var n = e.parent();
                n.hasClass(a.vertical) && this[n.hasClass(a.opened) ? "closePanel" : "openPanel"](e) }, getInstance: function() {
                return this }, bind: function(e, n) { this.cbck[e] = this.cbck[e] || [], this.cbck[e].push(n) }, trigger: function() {
                var e = this,
                    n = Array.prototype.slice.call(arguments),
                    t = n.shift();
                if (this.cbck[t])
                    for (var s = 0, a = this.cbck[t].length; a > s; s++) this.cbck[t][s].apply(e, n) }, _initMenu: function() { this.opts.offCanvas && this.conf.clone && (this.$menu = this.$menu.clone(!0), this.$menu.add(this.$menu.find("[id]")).filter("[id]").each(function() { e(this).attr("id", a.mm(e(this).attr("id"))) })), this.$menu.contents().each(function() { 3 == e(this)[0].nodeType && e(this).remove() }), this.$pnls = e('<div class="' + a.panels + '" />').append(this.$menu.children(this.conf.panelNodetype)).prependTo(this.$menu), this.$menu.parent().addClass(a.wrapper);
                var n = [a.menu];
                this.opts.slidingSubmenus || n.push(a.vertical), this.opts.extensions = this.opts.extensions.length ? "mm-" + this.opts.extensions.join(" mm-") : "", this.opts.extensions && n.push(this.opts.extensions), this.$menu.addClass(n.join(" ")) }, _initPanels: function(n) {
                var t = this,
                    s = this.__findAddBack(n, "ul, ol");
                this.__refactorClass(s, this.conf.classNames.inset, "inset").addClass(a.nolistview + " " + a.nopanel), s.not("." + a.nolistview).addClass(a.listview);
                var r = this.__findAddBack(n, "." + a.listview).children();
                this.__refactorClass(r, this.conf.classNames.selected, "selected"), this.__refactorClass(r, this.conf.classNames.divider, "divider"), this.__refactorClass(r, this.conf.classNames.spacer, "spacer"), this.__refactorClass(this.__findAddBack(n, "." + this.conf.classNames.panel), this.conf.classNames.panel, "panel");
                var l = e(),
                    d = n.add(n.find("." + a.panel)).add(this.__findAddBack(n, "." + a.listview).children().children(this.conf.panelNodetype)).not("." + a.nopanel);
                this.__refactorClass(d, this.conf.classNames.vertical, "vertical"), this.opts.slidingSubmenus || d.addClass(a.vertical), d.each(function() {
                    var n = e(this),
                        s = n;
                    n.is("ul, ol") ? (n.wrap('<div class="' + a.panel + '" />'), s = n.parent()) : s.addClass(a.panel);
                    var i = n.attr("id");
                    n.removeAttr("id"), s.attr("id", i || t.__getUniqueId()), n.hasClass(a.vertical) && (n.removeClass(t.conf.classNames.vertical), s.add(s.parent()).addClass(a.vertical)), l = l.add(s) });
                var o = e("." + a.panel, this.$menu);
                l.each(function() {
                    var n = e(this),
                        s = n.parent(),
                        r = s.children("a, span").first();
                    if (s.is("." + a.menu) || (s.data(i.sub, n), n.data(i.parent, s)), !s.children("." + a.next).length && s.parent().is("." + a.listview)) {
                        var l = n.attr("id"),
                            d = e('<a class="' + a.next + '" href="#' + l + '" data-target="#' + l + '" />').insertBefore(r);
                        r.is("span") && d.addClass(a.fullsubopen) }
                    if (!n.children("." + a.navbar).length && !s.hasClass(a.vertical)) {
                        if (s.parent().is("." + a.listview)) var s = s.closest("." + a.panel);
                        else var r = s.closest("." + a.panel).find('a[href="#' + n.attr("id") + '"]').first(),
                            s = r.closest("." + a.panel);
                        var o = e('<div class="' + a.navbar + '" />');
                        if (s.length) {
                            var l = s.attr("id");
                            switch (t.opts.navbar.titleLink) {
                                case "anchor":
                                    _url = r.attr("href");
                                    break;
                                case "panel":
                                case "parent":
                                    _url = "#" + l;
                                    break;
                                case "none":
                                default:
                                    _url = !1 }
                            o.append('<a class="' + a.btn + " " + a.prev + '" href="#' + l + '" data-target="#' + l + '" />').append(e('<a class="' + a.title + '"' + (_url ? ' href="' + _url + '"' : "") + " />").text(r.text())).prependTo(n), t.opts.navbar.add && n.addClass(a.hasnavbar) } else t.opts.navbar.title && (o.append('<a class="' + a.title + '">' + t.opts.navbar.title + "</a>").prependTo(n), t.opts.navbar.add && n.addClass(a.hasnavbar)) } });
                var c = this.__findAddBack(n, "." + a.listview).children("." + a.selected).removeClass(a.selected).last().addClass(a.selected);
                c.add(c.parentsUntil("." + a.menu, "li")).filter("." + a.vertical).addClass(a.opened).end().not("." + a.vertical).each(function() { e(this).parentsUntil("." + a.menu, "." + a.panel).not("." + a.vertical).first().addClass(a.opened).parentsUntil("." + a.menu, "." + a.panel).not("." + a.vertical).first().addClass(a.opened).addClass(a.subopened) }), c.children("." + a.panel).not("." + a.vertical).addClass(a.opened).parentsUntil("." + a.menu, "." + a.panel).not("." + a.vertical).first().addClass(a.opened).addClass(a.subopened);
                var h = o.filter("." + a.opened);
                return h.length || (h = l.first()), h.addClass(a.opened).last().addClass(a.current), l.not("." + a.vertical).not(h.last()).addClass(a.hidden).end().appendTo(this.$pnls), l }, _initAnchors: function() {
                var n = this;
                l.$body.on(r.click + "-oncanvas", "a[href]", function(s) {
                    var i = e(this),
                        r = !1,
                        l = n.$menu.find(i).length;
                    for (var d in e[t].addons)
                        if (r = e[t].addons[d].clickAnchor.call(n, i, l)) break;
                    if (!r && l) {
                        var o = i.attr("href");
                        if (o.length > 1 && "#" == o.slice(0, 1)) try {
                            var c = e(o, n.$menu);
                            c.is("." + a.panel) && (r = !0, n[i.parent().hasClass(a.vertical) ? "togglePanel" : "openPanel"](c)) } catch (h) {} }
                    if (r && s.preventDefault(), !r && l && i.is("." + a.listview + " > li > a") && !i.is('[rel="external"]') && !i.is('[target="_blank"]')) { n.__valueOrFn(n.opts.onClick.setSelected, i) && n.setSelected(e(s.target).parent());
                        var u = n.__valueOrFn(n.opts.onClick.preventDefault, i, "#" == o.slice(0, 1));
                        u && s.preventDefault(), n.__valueOrFn(n.opts.onClick.close, i, u) && n.close() } }) }, _initAddons: function() {
                for (var n in e[t].addons) e[t].addons[n].add.call(this), e[t].addons[n].add = function() {};
                for (var n in e[t].addons) e[t].addons[n].setup.call(this) }, __api: function() {
                var n = this,
                    t = {};
                return e.each(this._api, function() {
                    var e = this;
                    t[e] = function() {
                        var s = n[e].apply(n, arguments);
                        return "undefined" == typeof s ? t : s } }), t }, __valueOrFn: function(e, n, t) {
                return "function" == typeof e ? e.call(n[0]) : "undefined" == typeof e && "undefined" != typeof t ? t : e }, __refactorClass: function(e, n, t) {
                return e.filter("." + n).removeClass(n).addClass(a[t]) }, __findAddBack: function(e, n) {
                return e.find(n).add(e.filter(n)) }, __filterListItems: function(e) {
                return e.not("." + a.divider).not("." + a.hidden) }, __transitionend: function(e, n, t) {
                var s = !1,
                    a = function() { s || n.call(e[0]), s = !0 };
                e.one(r.transitionend, a), e.one(r.webkitTransitionEnd, a), setTimeout(a, 1.1 * t) }, __getUniqueId: function() {
                return a.mm(e[t].uniqueId++) } }, e.fn[t] = function(s, a) {
            return n(), s = e.extend(!0, {}, e[t].defaults, s), a = e.extend(!0, {}, e[t].configuration, a), this.each(function() {
                var n = e(this);
                if (!n.data(t)) {
                    var i = new e[t](n, s, a);
                    n.data(t, i.__api()) } }) }, e[t].support = { touch: "ontouchstart" in window || navigator.msMaxTouchPoints, csstransitions: function() {
                if ("undefined" != typeof Modernizr && "undefined" != typeof Modernizr.csstransitions) return Modernizr.csstransitions;
                var e = document.body || document.documentElement,
                    n = e.style,
                    t = "transition";
                if ("string" == typeof n[t]) return !0;
                var s = ["Moz", "webkit", "Webkit", "Khtml", "O", "ms"];
                t = t.charAt(0).toUpperCase() + t.substr(1);
                for (var a = 0; a < s.length; a++)
                    if ("string" == typeof n[s[a] + t]) return !0;
                return !1 }() };
        var a, i, r, l } }(jQuery);
/*	
 * jQuery mmenu offCanvas addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(e) {
    var t = "mmenu",
        o = "offCanvas";
    e[t].addons[o] = { setup: function() {
            if (this.opts[o]) {
                var s = this.opts[o],
                    i = this.conf[o];
                a = e[t].glbl, this._api = e.merge(this._api, ["open", "close", "setPage"]), ("top" == s.position || "bottom" == s.position) && (s.zposition = "front"), "string" != typeof i.pageSelector && (i.pageSelector = "> " + i.pageNodetype), a.$allMenus = (a.$allMenus || e()).add(this.$menu), this.vars.opened = !1;
                var r = [n.offcanvas]; "left" != s.position && r.push(n.mm(s.position)), "back" != s.zposition && r.push(n.mm(s.zposition)), this.$menu.addClass(r.join(" ")).parent().removeClass(n.wrapper), this.setPage(a.$page), this._initBlocker(), this["_initWindow_" + o](), this.$menu[i.menuInjectMethod + "To"](i.menuWrapperSelector) } }, add: function() { n = e[t]._c, s = e[t]._d, i = e[t]._e, n.add("offcanvas slideout blocking modal background opening blocker page"), s.add("style"), i.add("resize") }, clickAnchor: function(e) {
            if (!this.opts[o]) return !1;
            var t = this.$menu.attr("id");
            if (t && t.length && (this.conf.clone && (t = n.umm(t)), e.is('[href="#' + t + '"]'))) return this.open(), !0;
            if (a.$page) {
                var t = a.$page.first().attr("id");
                return t && t.length && e.is('[href="#' + t + '"]') ? (this.close(), !0) : !1 } } }, e[t].defaults[o] = { position: "left", zposition: "back", blockUI: !0, moveBackground: !0 }, e[t].configuration[o] = { pageNodetype: "div", pageSelector: null, noPageSelector: [], wrapPageIfNeeded: !0, menuWrapperSelector: "body", menuInjectMethod: "prepend" }, e[t].prototype.open = function() {
        if (!this.vars.opened) {
            var e = this;
            this._openSetup(), setTimeout(function() { e._openFinish() }, this.conf.openingInterval), this.trigger("open") } }, e[t].prototype._openSetup = function() {
        var t = this,
            r = this.opts[o];
        this.closeAllOthers(), a.$page.each(function() { e(this).data(s.style, e(this).attr("style") || "") }), a.$wndw.trigger(i.resize + "-" + o, [!0]);
        var p = [n.opened];
        r.blockUI && p.push(n.blocking), "modal" == r.blockUI && p.push(n.modal), r.moveBackground && p.push(n.background), "left" != r.position && p.push(n.mm(this.opts[o].position)), "back" != r.zposition && p.push(n.mm(this.opts[o].zposition)), this.opts.extensions && p.push(this.opts.extensions), a.$html.addClass(p.join(" ")), setTimeout(function() { t.vars.opened = !0 }, this.conf.openingInterval), this.$menu.addClass(n.current + " " + n.opened) }, e[t].prototype._openFinish = function() {
        var e = this;
        this.__transitionend(a.$page.first(), function() { e.trigger("opened") }, this.conf.transitionDuration), a.$html.addClass(n.opening), this.trigger("opening") }, e[t].prototype.close = function() {
        if (this.vars.opened) {
            var t = this;
            this.__transitionend(a.$page.first(), function() { t.$menu.removeClass(n.current).removeClass(n.opened), a.$html.removeClass(n.opened).removeClass(n.blocking).removeClass(n.modal).removeClass(n.background).removeClass(n.mm(t.opts[o].position)).removeClass(n.mm(t.opts[o].zposition)), t.opts.extensions && a.$html.removeClass(t.opts.extensions), a.$page.each(function() { e(this).attr("style", e(this).data(s.style)) }), t.vars.opened = !1, t.trigger("closed") }, this.conf.transitionDuration), a.$html.removeClass(n.opening), this.trigger("close"), this.trigger("closing") } }, e[t].prototype.closeAllOthers = function() { a.$allMenus.not(this.$menu).each(function() {
            var o = e(this).data(t);
            o && o.close && o.close() }) }, e[t].prototype.setPage = function(t) {
        var s = this,
            i = this.conf[o];
        t && t.length || (t = a.$body.find(i.pageSelector), i.noPageSelector.length && (t = t.not(i.noPageSelector.join(", "))), t.length > 1 && i.wrapPageIfNeeded && (t = t.wrapAll("<" + this.conf[o].pageNodetype + " />").parent())), t.each(function() { e(this).attr("id", e(this).attr("id") || s.__getUniqueId()) }), t.addClass(n.page + " " + n.slideout), a.$page = t, this.trigger("setPage", t) }, e[t].prototype["_initWindow_" + o] = function() { a.$wndw.off(i.keydown + "-" + o).on(i.keydown + "-" + o, function(e) {
            return a.$html.hasClass(n.opened) && 9 == e.keyCode ? (e.preventDefault(), !1) : void 0 });
        var e = 0;
        a.$wndw.off(i.resize + "-" + o).on(i.resize + "-" + o, function(t, o) {
            if (1 == a.$page.length && (o || a.$html.hasClass(n.opened))) {
                var s = a.$wndw.height();
                (o || s != e) && (e = s, a.$page.css("minHeight", s)) } }) }, e[t].prototype._initBlocker = function() {
        var t = this;
        this.opts[o].blockUI && (a.$blck || (a.$blck = e('<div id="' + n.blocker + '" class="' + n.slideout + '" />')), a.$blck.appendTo(a.$body).off(i.touchstart + "-" + o + " " + i.touchmove + "-" + o).on(i.touchstart + "-" + o + " " + i.touchmove + "-" + o, function(e) { e.preventDefault(), e.stopPropagation(), a.$blck.trigger(i.mousedown + "-" + o) }).off(i.mousedown + "-" + o).on(i.mousedown + "-" + o, function(e) { e.preventDefault(), a.$html.hasClass(n.modal) || (t.closeAllOthers(), t.close()) })) };
    var n, s, i, a }(jQuery);
/*	
 * jQuery mmenu autoHeight addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(t) {
    var e = "mmenu",
        s = "autoHeight";
    t[e].addons[s] = { setup: function() {
            if (this.opts.offCanvas) {
                switch (this.opts.offCanvas.position) {
                    case "left":
                    case "right":
                        return }
                var n = this,
                    o = this.opts[s];
                if (this.conf[s], h = t[e].glbl, "boolean" == typeof o && o && (o = { height: "auto" }), "object" != typeof o && (o = {}), o = this.opts[s] = t.extend(!0, {}, t[e].defaults[s], o), "auto" == o.height) { this.$menu.addClass(i.autoheight);
                    var u = function(t) {
                        var e = parseInt(this.$pnls.css("top"), 10) || 0;
                        _bot = parseInt(this.$pnls.css("bottom"), 10) || 0, this.$menu.addClass(i.measureheight), t = t || this.$pnls.children("." + i.current), t.is("." + i.vertical) && (t = t.parents("." + i.panel).not("." + i.vertical).first()), this.$menu.height(t.outerHeight() + e + _bot).removeClass(i.measureheight) };
                    this.bind("update", u), this.bind("openPanel", u), this.bind("closePanel", u), this.bind("open", u), h.$wndw.off(a.resize + "-autoheight").on(a.resize + "-autoheight", function() { u.call(n) }) } } }, add: function() { i = t[e]._c, n = t[e]._d, a = t[e]._e, i.add("autoheight measureheight"), a.add("resize") }, clickAnchor: function() {} }, t[e].defaults[s] = { height: "default" };
    var i, n, a, h }(jQuery);
/*	
 * jQuery mmenu backButton addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(o) {
    var t = "mmenu",
        n = "backButton";
    o[t].addons[n] = { setup: function() {
            if (this.opts.offCanvas) {
                var i = this,
                    e = this.opts[n];
                if (this.conf[n], a = o[t].glbl, "boolean" == typeof e && (e = { close: e }), "object" != typeof e && (e = {}), e = o.extend(!0, {}, o[t].defaults[n], e), e.close) {
                    var c = "#" + i.$menu.attr("id");
                    this.bind("opened", function() { location.hash != c && history.pushState(null, document.title, c) }), o(window).on("popstate", function(o) { a.$html.hasClass(s.opened) ? (o.stopPropagation(), i.close()) : location.hash == c && (o.stopPropagation(), i.open()) }) } } }, add: function() {
            return window.history && window.history.pushState ? (s = o[t]._c, i = o[t]._d, void(e = o[t]._e)) : void(o[t].addons[n].setup = function() {}) }, clickAnchor: function() {} }, o[t].defaults[n] = { close: !1 };
    var s, i, e, a }(jQuery);
/*	
 * jQuery mmenu counters addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(t) {
    var n = "mmenu",
        e = "counters";
    t[n].addons[e] = { setup: function() {
            var s = this,
                o = this.opts[e];
            this.conf[e], c = t[n].glbl, "boolean" == typeof o && (o = { add: o, update: o }), "object" != typeof o && (o = {}), o = this.opts[e] = t.extend(!0, {}, t[n].defaults[e], o), this.bind("init", function(n) { this.__refactorClass(t("em", n), this.conf.classNames[e].counter, "counter") }), o.add && this.bind("init", function(n) { n.each(function() {
                    var n = t(this).data(a.parent);
                    n && (n.children("em." + i.counter).length || n.prepend(t('<em class="' + i.counter + '" />'))) }) }), o.update && this.bind("update", function() { this.$pnls.find("." + i.panel).each(function() {
                    var n = t(this),
                        e = n.data(a.parent);
                    if (e) {
                        var c = e.children("em." + i.counter);
                        c.length && (n = n.children("." + i.listview), n.length && c.html(s.__filterListItems(n.children()).length)) } }) }) }, add: function() { i = t[n]._c, a = t[n]._d, s = t[n]._e, i.add("counter search noresultsmsg") }, clickAnchor: function() {} }, t[n].defaults[e] = { add: !1, update: !1 }, t[n].configuration.classNames[e] = { counter: "Counter" };
    var i, a, s, c }(jQuery);
/*	
 * jQuery mmenu dividers addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(i) {
    var e = "mmenu",
        s = "dividers";
    i[e].addons[s] = { setup: function() {
            var n = this,
                a = this.opts[s];
            if (this.conf[s], l = i[e].glbl, "boolean" == typeof a && (a = { add: a, fixed: a }), "object" != typeof a && (a = {}), a = this.opts[s] = i.extend(!0, {}, i[e].defaults[s], a), this.bind("init", function() { this.__refactorClass(i("li", this.$menu), this.conf.classNames[s].collapsed, "collapsed") }), a.add && this.bind("init", function(e) {
                    switch (a.addTo) {
                        case "panels":
                            var s = e;
                            break;
                        default:
                            var s = i(a.addTo, this.$pnls).filter("." + d.panel) }
                    i("." + d.divider, s).remove(), s.find("." + d.listview).not("." + d.vertical).each(function() {
                        var e = "";
                        n.__filterListItems(i(this).children()).each(function() {
                            var s = i.trim(i(this).children("a, span").text()).slice(0, 1).toLowerCase();
                            s != e && s.length && (e = s, i('<li class="' + d.divider + '">' + s + "</li>").insertBefore(this)) }) }) }), a.collapse && this.bind("init", function(e) { i("." + d.divider, e).each(function() {
                        var e = i(this),
                            s = e.nextUntil("." + d.divider, "." + d.collapsed);
                        s.length && (e.children("." + d.subopen).length || (e.wrapInner("<span />"), e.prepend('<a href="#" class="' + d.subopen + " " + d.fullsubopen + '" />'))) }) }), a.fixed) {
                var o = function(e) { e = e || this.$pnls.children("." + d.current);
                    var s = e.find("." + d.divider).not("." + d.hidden);
                    if (s.length) { this.$menu.addClass(d.hasdividers);
                        var n = e.scrollTop() || 0,
                            t = "";
                        e.is(":visible") && e.find("." + d.divider).not("." + d.hidden).each(function() { i(this).position().top + n < n + 1 && (t = i(this).text()) }), this.$fixeddivider.text(t) } else this.$menu.removeClass(d.hasdividers) };
                this.$fixeddivider = i('<ul class="' + d.listview + " " + d.fixeddivider + '"><li class="' + d.divider + '"></li></ul>').prependTo(this.$pnls).children(), this.bind("openPanel", o), this.bind("init", function(e) { e.off(t.scroll + "-dividers " + t.touchmove + "-dividers").on(t.scroll + "-dividers " + t.touchmove + "-dividers", function() { o.call(n, i(this)) }) }) } }, add: function() { d = i[e]._c, n = i[e]._d, t = i[e]._e, d.add("collapsed uncollapsed fixeddivider hasdividers"), t.add("scroll") }, clickAnchor: function(i, e) {
            if (this.opts[s].collapse && e) {
                var n = i.parent();
                if (n.is("." + d.divider)) {
                    var t = n.nextUntil("." + d.divider, "." + d.collapsed);
                    return n.toggleClass(d.opened), t[n.hasClass(d.opened) ? "addClass" : "removeClass"](d.uncollapsed), !0 } }
            return !1 } }, i[e].defaults[s] = { add: !1, addTo: "panels", fixed: !1, collapse: !1 }, i[e].configuration.classNames[s] = { collapsed: "Collapsed" };
    var d, n, t, l }(jQuery);
/*	
 * jQuery mmenu dragOpen addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(e) {
    function t(e, t, n) {
        return t > e && (e = t), e > n && (e = n), e }
    var n = "mmenu",
        o = "dragOpen";
    e[n].addons[o] = { setup: function() {
            if (this.opts.offCanvas) {
                var i = this,
                    a = this.opts[o],
                    p = this.conf[o];
                if (r = e[n].glbl, "boolean" == typeof a && (a = { open: a }), "object" != typeof a && (a = {}), a = this.opts[o] = e.extend(!0, {}, e[n].defaults[o], a), a.open) {
                    var d, f, c, u, h, l = {},
                        m = 0,
                        g = !1,
                        v = !1,
                        w = 0,
                        _ = 0;
                    switch (this.opts.offCanvas.position) {
                        case "left":
                        case "right":
                            l.events = "panleft panright", l.typeLower = "x", l.typeUpper = "X", v = "width";
                            break;
                        case "top":
                        case "bottom":
                            l.events = "panup pandown", l.typeLower = "y", l.typeUpper = "Y", v = "height" }
                    switch (this.opts.offCanvas.position) {
                        case "right":
                        case "bottom":
                            l.negative = !0, u = function(e) { e >= r.$wndw[v]() - a.maxStartPos && (m = 1) };
                            break;
                        default:
                            l.negative = !1, u = function(e) { e <= a.maxStartPos && (m = 1) } }
                    switch (this.opts.offCanvas.position) {
                        case "left":
                            l.open_dir = "right", l.close_dir = "left";
                            break;
                        case "right":
                            l.open_dir = "left", l.close_dir = "right";
                            break;
                        case "top":
                            l.open_dir = "down", l.close_dir = "up";
                            break;
                        case "bottom":
                            l.open_dir = "up", l.close_dir = "down" }
                    switch (this.opts.offCanvas.zposition) {
                        case "front":
                            h = function() {
                                return this.$menu };
                            break;
                        default:
                            h = function() {
                                return e("." + s.slideout) } }
                    var b = this.__valueOrFn(a.pageNode, this.$menu, r.$page); "string" == typeof b && (b = e(b));
                    var y = new Hammer(b[0], a.vendors.hammer);
                    y.on("panstart", function(e) { u(e.center[l.typeLower]), r.$slideOutNodes = h(), g = l.open_dir }).on(l.events + " panend", function(e) { m > 0 && e.preventDefault() }).on(l.events, function(e) {
                        if (d = e["delta" + l.typeUpper], l.negative && (d = -d), d != w && (g = d >= w ? l.open_dir : l.close_dir), w = d, w > a.threshold && 1 == m) {
                            if (r.$html.hasClass(s.opened)) return;
                            m = 2, i._openSetup(), i.trigger("opening"), r.$html.addClass(s.dragging), _ = t(r.$wndw[v]() * p[v].perc, p[v].min, p[v].max) }
                        2 == m && (f = t(w, 10, _) - ("front" == i.opts.offCanvas.zposition ? _ : 0), l.negative && (f = -f), c = "translate" + l.typeUpper + "(" + f + "px )", r.$slideOutNodes.css({ "-webkit-transform": "-webkit-" + c, transform: c })) }).on("panend", function() { 2 == m && (r.$html.removeClass(s.dragging), r.$slideOutNodes.css("transform", ""), i[g == l.open_dir ? "_openFinish" : "close"]()), m = 0 }) } } }, add: function() {
            return "function" != typeof Hammer || Hammer.VERSION < 2 ? void(e[n].addons[o].setup = function() {}) : (s = e[n]._c, i = e[n]._d, a = e[n]._e, void s.add("dragging")) }, clickAnchor: function() {} }, e[n].defaults[o] = { open: !1, maxStartPos: 100, threshold: 50, vendors: { hammer: {} } }, e[n].configuration[o] = { width: { perc: .8, min: 140, max: 440 }, height: { perc: .8, min: 140, max: 880 } };
    var s, i, a, r }(jQuery);
/*	
 * jQuery mmenu fixedElements addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(s) {
    var i = "mmenu",
        t = "fixedElements";
    s[i].addons[t] = { setup: function() {
            if (this.opts.offCanvas) {
                var n = this.opts[t];
                this.conf[t], d = s[i].glbl, n = this.opts[t] = s.extend(!0, {}, s[i].defaults[t], n);
                var a = function(s) {
                    var i = this.conf.classNames[t].fixed;
                    this.__refactorClass(s.find("." + i), i, "slideout").appendTo(d.$body) };
                a.call(this, d.$page), this.bind("setPage", a) } }, add: function() { n = s[i]._c, a = s[i]._d, e = s[i]._e, n.add("fixed") }, clickAnchor: function() {} }, s[i].configuration.classNames[t] = { fixed: "Fixed" };
    var n, a, e, d }(jQuery);
/*	
 * jQuery mmenu iconPanels addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(e) {
    var n = "mmenu",
        i = "iconPanels";
    e[n].addons[i] = { setup: function() {
            var a = this,
                l = this.opts[i];
            if (this.conf[i], d = e[n].glbl, "boolean" == typeof l && (l = { add: l }), "number" == typeof l && (l = { add: !0, visible: l }), "object" != typeof l && (l = {}), l = this.opts[i] = e.extend(!0, {}, e[n].defaults[i], l), l.visible++, l.add) { this.$menu.addClass(s.iconpanel);
                for (var t = [], o = 0; o <= l.visible; o++) t.push(s.iconpanel + "-" + o);
                t = t.join(" ");
                var c = function(n) {
                    var i = a.$pnls.children("." + s.panel).removeClass(t),
                        d = i.filter("." + s.subopened);
                    d.removeClass(s.hidden).add(n).slice(-l.visible).each(function(n) { e(this).addClass(s.iconpanel + "-" + n) }) };
                this.bind("openPanel", c), this.bind("init", function(n) { c.call(a, a.$pnls.children("." + s.current)), l.hideNavbars && n.removeClass(s.hasnavbar), n.each(function() { e(this).children("." + s.subblocker).length || e(this).prepend('<a href="#' + e(this).closest("." + s.panel).attr("id") + '" class="' + s.subblocker + '" />') }) }) } }, add: function() { s = e[n]._c, a = e[n]._d, l = e[n]._e, s.add("iconpanel subblocker") }, clickAnchor: function() {} }, e[n].defaults[i] = { add: !1, visible: 3, hideNavbars: !1 };
    var s, a, l, d }(jQuery);
/*	
 * jQuery mmenu navbar addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(n) {
    var a = "mmenu",
        t = "navbars";
    n[a].addons[t] = { setup: function() {
            var r = this,
                s = this.opts[t],
                c = this.conf[t];
            if (i = n[a].glbl, "undefined" != typeof s) { s instanceof Array || (s = [s]);
                var d = {};
                n.each(s, function(i) {
                    var o = s[i]; "boolean" == typeof o && o && (o = {}), "object" != typeof o && (o = {}), "undefined" == typeof o.content && (o.content = ["prev", "title"]), o.content instanceof Array || (o.content = [o.content]), o = n.extend(!0, {}, r.opts.navbar, o);
                    var l = o.position,
                        h = o.height; "number" != typeof h && (h = 1), h = Math.min(4, Math.max(1, h)), "bottom" != l && (l = "top"), d[l] || (d[l] = 0), d[l]++;
                    var f = n("<div />").addClass(e.navbar + " " + e.navbar + "-" + l + " " + e.navbar + "-" + l + "-" + d[l] + " " + e.navbar + "-size-" + h);
                    d[l] += h - 1;
                    for (var v = 0, p = o.content.length; p > v; v++) {
                        var u = n[a].addons[t][o.content[v]] || !1;
                        u ? u.call(r, f, o, c) : (u = o.content[v], u instanceof n || (u = n(o.content[v])), u.each(function() { f.append(n(this)) })) }
                    var b = Math.ceil(f.children().not("." + e.btn).length / h);
                    b > 1 && f.addClass(e.navbar + "-content-" + b), f.children("." + e.btn).length && f.addClass(e.hasbtns), f.prependTo(r.$menu) });
                for (var o in d) r.$menu.addClass(e.hasnavbar + "-" + o + "-" + d[o]) } }, add: function() { e = n[a]._c, r = n[a]._d, s = n[a]._e, e.add("close hasbtns") }, clickAnchor: function() {} }, n[a].configuration[t] = { breadcrumbSeparator: "/" }, n[a].configuration.classNames[t] = { panelTitle: "Title", panelNext: "Next", panelPrev: "Prev" };
    var e, r, s, i }(jQuery),
/*	
 * jQuery mmenu navbar addon breadcrumbs content
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
function(n) {
    var a = "mmenu",
        t = "navbars",
        e = "breadcrumbs";
    n[a].addons[t][e] = function(t, e, r) {
        var s = n[a]._c,
            i = n[a]._d;
        s.add("breadcrumbs separator"), t.append('<span class="' + s.breadcrumbs + '"></span>'), this.bind("init", function(a) { a.removeClass(s.hasnavbar).each(function() {
                for (var a = [], t = n(this), e = n('<span class="' + s.breadcrumbs + '"></span>'), c = n(this).children().first(), d = !0; c && c.length;) { c.is("." + s.panel) || (c = c.closest("." + s.panel));
                    var o = c.children("." + s.navbar).children("." + s.title).text();
                    a.unshift(d ? "<span>" + o + "</span>" : '<a href="#' + c.attr("id") + '">' + o + "</a>"), d = !1, c = c.data(i.parent) }
                e.append(a.join('<span class="' + s.separator + '">' + r.breadcrumbSeparator + "</span>")).appendTo(t.children("." + s.navbar)) }) });
        var c = function() {
            var n = this.$pnls.children("." + s.current),
                a = t.find("." + s.breadcrumbs),
                e = n.children("." + s.navbar).children("." + s.breadcrumbs);
            a.html(e.html()) };
        this.bind("openPanel", c), this.bind("init", c) } }(jQuery),
/*	
 * jQuery mmenu navbar addon close content
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
function(n) {
    var a = "mmenu",
        t = "navbars",
        e = "close";
    n[a].addons[t][e] = function(t) {
        var e = n[a]._c,
            r = n[a].glbl;
        t.append('<a class="' + e.close + " " + e.btn + '" href="#"></a>');
        var s = function(n) { t.find("." + e.close).attr("href", "#" + n.attr("id")) };
        s.call(this, r.$page), this.bind("setPage", s) } }(jQuery),
/*	
 * jQuery mmenu navbar addon next content
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
function(n) {
    var a = "mmenu",
        t = "navbars",
        e = "next";
    n[a].addons[t][e] = function(e) {
        var r = n[a]._c;
        e.append('<a class="' + r.next + " " + r.btn + '" href="#"></a>');
        var s = function(n) { n = n || this.$pnls.children("." + r.current);
            var a = e.find("." + r.next),
                s = n.find("." + this.conf.classNames[t].panelNext),
                i = s.attr("href"),
                c = s.html();
            a[i ? "attr" : "removeAttr"]("href", i), a[i || c ? "removeClass" : "addClass"](r.hidden), a.html(c) };
        this.bind("openPanel", s), this.bind("init", function() { s.call(this) }) } }(jQuery),
/*	
 * jQuery mmenu navbar addon prev content
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
function(n) {
    var a = "mmenu",
        t = "navbars",
        e = "prev";
    n[a].addons[t][e] = function(e) {
        var r = n[a]._c;
        e.append('<a class="' + r.prev + " " + r.btn + '" href="#"></a>'), this.bind("init", function(n) { n.removeClass(r.hasnavbar) });
        var s = function() {
            var n = this.$pnls.children("." + r.current),
                a = e.find("." + r.prev),
                s = n.find("." + this.conf.classNames[t].panelPrev);
            s.length || (s = n.children("." + r.navbar).children("." + r.prev));
            var i = s.attr("href"),
                c = s.html();
            a[i ? "attr" : "removeAttr"]("href", i), a[i || c ? "removeClass" : "addClass"](r.hidden), a.html(c) };
        this.bind("openPanel", s), this.bind("init", s) } }(jQuery),
/*	
 * jQuery mmenu navbar addon searchfield content
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
function(n) {
    var a = "mmenu",
        t = "navbars",
        e = "searchfield";
    n[a].addons[t][e] = function(t) {
        var e = n[a]._c,
            r = n('<div class="' + e.search + '" />').appendTo(t); "object" != typeof this.opts.searchfield && (this.opts.searchfield = {}), this.opts.searchfield.add = !0, this.opts.searchfield.addTo = r } }(jQuery),
/*	
 * jQuery mmenu navbar addon title content
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
function(n) {
    var a = "mmenu",
        t = "navbars",
        e = "title";
    n[a].addons[t][e] = function(e, r) {
        var s = n[a]._c;
        e.append('<a class="' + s.title + '"></a>');
        var i = function(n) { n = n || this.$pnls.children("." + s.current);
            var a = e.find("." + s.title),
                i = n.find("." + this.conf.classNames[t].panelTitle);
            i.length || (i = n.children("." + s.navbar).children("." + s.title));
            var c = i.attr("href"),
                d = i.html() || r.title;
            a[c ? "attr" : "removeAttr"]("href", c), a[c || d ? "removeClass" : "addClass"](s.hidden), a.html(d) };
        this.bind("openPanel", i), this.bind("init", function() { i.call(this) }) } }(jQuery);
/*	
 * jQuery mmenu searchfield addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(e) {
    function s(e) {
        switch (e) {
            case 9:
            case 16:
            case 17:
            case 18:
            case 37:
            case 38:
            case 39:
            case 40:
                return !0 }
        return !1 }
    var n = "mmenu",
        a = "searchfield";
    e[n].addons[a] = { setup: function() {
            var o = this,
                d = this.opts[a],
                c = this.conf[a];
            r = e[n].glbl, "boolean" == typeof d && (d = { add: d }), "object" != typeof d && (d = {}), d = this.opts[a] = e.extend(!0, {}, e[n].defaults[a], d), this.bind("close", function() { this.$menu.find("." + l.search).find("input").blur() }), this.bind("init", function(n) {
                if (d.add) {
                    switch (d.addTo) {
                        case "panels":
                            var a = n;
                            break;
                        default:
                            var a = e(d.addTo, this.$menu) }
                    a.each(function() {
                        var s = e(this);
                        if (!s.is("." + l.panel) || !s.is("." + l.vertical)) {
                            if (!s.children("." + l.search).length) {
                                var n = c.form ? "form" : "div",
                                    a = e("<" + n + ' class="' + l.search + '" />');
                                if (c.form && "object" == typeof c.form)
                                    for (var t in c.form) a.attr(t, c.form[t]);
                                a.append('<input placeholder="' + d.placeholder + '" type="text" autocomplete="off" />'), s.hasClass(l.search) ? s.replaceWith(a) : s.prepend(a).addClass(l.hassearch) }
                            if (d.noResults) {
                                var i = s.closest("." + l.panel).length;
                                if (i || (s = o.$pnls.children("." + l.panel).first()), !s.children("." + l.noresultsmsg).length) {
                                    var r = s.children("." + l.listview).first();
                                    e('<div class="' + l.noresultsmsg + '" />').append(d.noResults)[r.length ? "insertAfter" : "prependTo"](r.length ? r : s) } } } }), d.search && e("." + l.search, this.$menu).each(function() {
                        var n = e(this),
                            a = n.closest("." + l.panel).length;
                        if (a) var r = n.closest("." + l.panel),
                            c = r;
                        else var r = e("." + l.panel, o.$menu),
                            c = o.$menu;
                        var h = n.children("input"),
                            u = o.__findAddBack(r, "." + l.listview).children("li"),
                            f = u.filter("." + l.divider),
                            p = o.__filterListItems(u),
                            v = "> a",
                            m = v + ", > span",
                            b = function() {
                                var s = h.val().toLowerCase();
                                r.scrollTop(0), p.add(f).addClass(l.hidden).find("." + l.fullsubopensearch).removeClass(l.fullsubopen).removeClass(l.fullsubopensearch), p.each(function() {
                                    var n = e(this),
                                        a = v;
                                    (d.showTextItems || d.showSubPanels && n.find("." + l.next)) && (a = m), e(a, n).text().toLowerCase().indexOf(s) > -1 && n.add(n.prevAll("." + l.divider).first()).removeClass(l.hidden) }), d.showSubPanels && r.each(function() {
                                    var s = e(this);
                                    o.__filterListItems(s.find("." + l.listview).children()).each(function() {
                                        var s = e(this),
                                            n = s.data(t.sub);
                                        s.removeClass(l.nosubresults), n && n.find("." + l.listview).children().removeClass(l.hidden) }) }), e(r.get().reverse()).each(function(s) {
                                    var n = e(this),
                                        i = n.data(t.parent);
                                    i && (o.__filterListItems(n.find("." + l.listview).children()).length ? (i.hasClass(l.hidden) && i.children("." + l.next).not("." + l.fullsubopen).addClass(l.fullsubopen).addClass(l.fullsubopensearch), i.removeClass(l.hidden).removeClass(l.nosubresults).prevAll("." + l.divider).first().removeClass(l.hidden)) : a || (n.hasClass(l.opened) && setTimeout(function() { o.openPanel(i.closest("." + l.panel)) }, 1.5 * (s + 1) * o.conf.openingInterval), i.addClass(l.nosubresults))) }), c[p.not("." + l.hidden).length ? "removeClass" : "addClass"](l.noresults), this.update() };
                        h.off(i.keyup + "-searchfield " + i.change + "-searchfield").on(i.keyup + "-searchfield", function(e) { s(e.keyCode) || b.call(o) }).on(i.change + "-searchfield", function() { b.call(o) }) }) } }) }, add: function() { l = e[n]._c, t = e[n]._d, i = e[n]._e, l.add("search hassearch noresultsmsg noresults nosubresults fullsubopensearch"), i.add("change keyup") }, clickAnchor: function() {} }, e[n].defaults[a] = { add: !1, addTo: "panels", search: !0, placeholder: "Search", noResults: "No results found.", showTextItems: !1, showSubPanels: !0 }, e[n].configuration[a] = { form: !1 };
    var l, t, i, r }(jQuery);
/*	
 * jQuery mmenu sectionIndexer addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(e) {
    var a = "mmenu",
        r = "sectionIndexer";
    e[a].addons[r] = { setup: function() {
            var i = this,
                d = this.opts[r];
            this.conf[r], t = e[a].glbl, "boolean" == typeof d && (d = { add: d }), "object" != typeof d && (d = {}), d = this.opts[r] = e.extend(!0, {}, e[a].defaults[r], d), this.bind("init", function(a) {
                if (d.add) {
                    switch (d.addTo) {
                        case "panels":
                            var r = a;
                            break;
                        default:
                            var r = e(d.addTo, this.$menu).filter("." + n.panel) }
                    r.find("." + n.divider).closest("." + n.panel).addClass(n.hasindexer) }
                if (!this.$indexer && this.$pnls.children("." + n.hasindexer).length) { this.$indexer = e('<div class="' + n.indexer + '" />').prependTo(this.$pnls).append('<a href="#a">a</a><a href="#b">b</a><a href="#c">c</a><a href="#d">d</a><a href="#e">e</a><a href="#f">f</a><a href="#g">g</a><a href="#h">h</a><a href="#i">i</a><a href="#j">j</a><a href="#k">k</a><a href="#l">l</a><a href="#m">m</a><a href="#n">n</a><a href="#o">o</a><a href="#p">p</a><a href="#q">q</a><a href="#r">r</a><a href="#s">s</a><a href="#t">t</a><a href="#u">u</a><a href="#v">v</a><a href="#w">w</a><a href="#x">x</a><a href="#y">y</a><a href="#z">z</a>'), this.$indexer.children().on(s.mouseover + "-sectionindexer " + n.touchstart + "-sectionindexer", function() {
                        var a = e(this).attr("href").slice(1),
                            r = i.$pnls.children("." + n.current),
                            s = r.find("." + n.listview),
                            t = !1,
                            d = r.scrollTop(),
                            h = s.position().top + parseInt(s.css("margin-top"), 10) + parseInt(s.css("padding-top"), 10) + d;
                        r.scrollTop(0), s.children("." + n.divider).not("." + n.hidden).each(function() { t === !1 && a == e(this).text().slice(0, 1).toLowerCase() && (t = e(this).position().top + h) }), r.scrollTop(t !== !1 ? t : d) });
                    var t = function(e) { i.$menu[(e.hasClass(n.hasindexer) ? "add" : "remove") + "Class"](n.hasindexer) };
                    this.bind("openPanel", t), t.call(this, this.$pnls.children("." + n.current)) } }) }, add: function() { n = e[a]._c, i = e[a]._d, s = e[a]._e, n.add("indexer hasindexer"), s.add("mouseover touchstart") }, clickAnchor: function(e) {
            return e.parent().is("." + n.indexer) ? !0 : void 0 } }, e[a].defaults[r] = { add: !1, addTo: "panels" };
    var n, i, s, t }(jQuery);
/*	
 * jQuery mmenu toggles addon
 * mmenu.frebsite.nl
 *
 * Copyright (c) Fred Heusschen
 */
! function(t) {
    var e = "mmenu",
        c = "toggles";
    t[e].addons[c] = { setup: function() {
            var n = this;
            this.opts[c], this.conf[c], l = t[e].glbl, this.bind("init", function(e) { this.__refactorClass(t("input", e), this.conf.classNames[c].toggle, "toggle"), this.__refactorClass(t("input", e), this.conf.classNames[c].check, "check"), t("input." + s.toggle + ", input." + s.check, e).each(function() {
                    var e = t(this),
                        c = e.closest("li"),
                        i = e.hasClass(s.toggle) ? "toggle" : "check",
                        l = e.attr("id") || n.__getUniqueId();
                    c.children('label[for="' + l + '"]').length || (e.attr("id", l), c.prepend(e), t('<label for="' + l + '" class="' + s[i] + '"></label>').insertBefore(c.children("a, span").last())) }) }) }, add: function() { s = t[e]._c, n = t[e]._d, i = t[e]._e, s.add("toggle check") }, clickAnchor: function() {} }, t[e].configuration.classNames[c] = { toggle: "Toggle", check: "Check" };
    var s, n, i, l }(jQuery); // JavaScript Document